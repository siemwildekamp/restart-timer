package com.servershutdown;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

public class ServerShutdownPlugin extends JavaPlugin {
    @Override
    public void onEnable() {
        this.getCommand("server-shutdown").setExecutor((sender, command, label, args) -> {
            if (!sender.hasPermission("servershutdown.admin")) {
                sender.sendMessage(ChatColor.RED + "You don't have permission to use this command!");
                return true;
            }

            // Start countdown from 60 seconds
            new BukkitRunnable() {
                int timeLeft = 60;

                @Override
                public void run() {
                    if (timeLeft <= 0) {
                        Bukkit.broadcastMessage(ChatColor.RED + "Server restarting now!");
                        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "restart");
                        cancel();
                        return;
                    }

                    if (timeLeft <= 10 || timeLeft % 10 == 0) {
                        Bukkit.broadcastMessage(ChatColor.YELLOW + "Server restarting in " + 
                            ChatColor.RED + timeLeft + ChatColor.YELLOW + " seconds!");
                    }

                    timeLeft--;
                }
            }.runTaskTimer(this, 0L, 20L); // 20 ticks = 1 second

            return true;
        });
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
}